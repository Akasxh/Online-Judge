export const BACKEND_URL="https://online-judge-gargi.onrender.com/"
